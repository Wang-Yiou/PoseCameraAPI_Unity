Copyright 2021 Pose AI Ltd.

This API is restricted to licensed partners.  It can also be used privately (i.e. not distributed or commercialized) by developers for evaluation of our technology or as part of our open beta.